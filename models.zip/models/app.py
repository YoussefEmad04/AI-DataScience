from flask import Flask, request, render_template
import numpy as np
import joblib
import os

app = Flask(__name__)

# Feature names and descriptions
FEATURES = [
    ('radius_mean', 'Mean of distances from center to points on the perimeter'),
    ('texture_mean', 'Standard deviation of gray-scale values'),
    ('perimeter_mean', 'Mean size of the core tumor'),
    ('area_mean', 'Mean area of the tumor'),
    ('smoothness_mean', 'Mean of local variation in radius lengths'),
    ('compactness_mean', 'Mean of perimeter^2 / area - 1.0'),
    ('concavity_mean', 'Mean of severity of concave portions of the contour'),
    ('concave points_mean', 'Mean for number of concave portions of the contour'),
    ('symmetry_mean', 'Mean of symmetry of the tumor'),
    ('fractal_dimension_mean', 'Mean for "coastline approximation" - 1'),
    ('radius_se', 'Standard error for the mean of distances from center to points'),
    ('texture_se', 'Standard error for texture'),
    ('perimeter_se', 'Standard error for perimeter'),
    ('area_se', 'Standard error for area'),
    ('smoothness_se', 'Standard error for smoothness'),
    ('compactness_se', 'Standard error for compactness'),
    ('concavity_se', 'Standard error for concavity'),
    ('concave points_se', 'Standard error for concave points'),
    ('symmetry_se', 'Standard error for symmetry'),
    ('fractal_dimension_se', 'Standard error for fractal dimension'),
    ('radius_worst', 'Worst or largest mean value for radius'),
    ('texture_worst', 'Worst or largest mean value for texture'),
    ('perimeter_worst', 'Worst or largest mean value for perimeter'),
    ('area_worst', 'Worst or largest mean value for area'),
    ('smoothness_worst', 'Worst or largest mean value for smoothness')
]

# Load all models
models = {
    'Logistic Regression': joblib.load('logistic_regression_model.pkl'),
    'Random Forest': joblib.load('random_forest_model.pkl'),
    'SVC (Linear)': joblib.load('svc_linear_model.pkl'),
    'SVC (RBF)': joblib.load('svc_rbf_model.pkl'),
    'KNN': joblib.load('knn_model.pkl'),
    'Decision Tree': joblib.load('decision_tree_model.pkl')
}

# Load the scaler
scaler = joblib.load('robust_scaler.pkl')

@app.route('/')
def home():
    return render_template('index.html', features=FEATURES, models=models.keys())

@app.route('/classify', methods=['POST'])
def classify():
    try:
        # Get selected model
        selected_model = request.form.get('model')
        if selected_model not in models:
            return render_template('index.html', 
                                error='Invalid model selection',
                                models=models.keys(),
                                features=FEATURES)
        
        # Get feature values
        feature_values = []
        for i in range(len(FEATURES)):
            value = request.form.get(f'feature_{i}')
            if value is None:
                return render_template('index.html',
                                    error=f'Missing value for {FEATURES[i][0]}',
                                    models=models.keys(),
                                    features=FEATURES)
            feature_values.append(float(value))
        
        # Prepare and scale features
        X = np.array(feature_values).reshape(1, -1)
        X_scaled = scaler.transform(X)
        
        # Make classification
        model = models[selected_model]
        classification = model.predict(X_scaled)[0]
        result = 'Malignant' if classification == 1 else 'Benign'
        
        return render_template('index.html',
                             models=models.keys(),
                             features=FEATURES,
                             values=feature_values,
                             selected_model=selected_model,
                             classification=result)
    
    except ValueError as e:
        return render_template('index.html',
                             error='Invalid input. Please enter valid numeric values.',
                             models=models.keys(),
                             features=FEATURES)
    except Exception as e:
        return render_template('index.html',
                             error=f'An error occurred: {str(e)}',
                             models=models.keys(),
                             features=FEATURES)

if __name__ == '__main__':
    app.run(debug=True)
